package ui;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MerrenLoginClass {

	public static void main(String[] args)throws InterruptedException{
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		  driver.get("https://www.calculator.net/");
		//driver.get("https://demo.merren.io/accounts/login/");
		//driver.get("https://demo.merren.io/accounts/signup/");
		//driver.get("https://www.facebook.com/");
		// driver.findElementByCssSelector("#login > li:nth-child(1) > app-email-input >
		// div > input").sendKeys("sneha");
		// driver.findElement(By.id("//*[@id=\"login\"]/li[1]/app-email-input/div/input")).sendKeys("sneha");
		// driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("sneha");
		// driver.findElement(By.cssSelector("#email")).sendKeys("sneha");
		// driver.findElement(By.xpath("//*[@id=\"login\"]/li[1]/app-email-input/div/input")).sendKeys("snehapanjiyar2017@gmail.com");
//		driver.findElement(By.xpath("//*[@id=\"login\"]/li[2]/app-password/div/input")).sendKeys("Test@123");
//		driver.findElement(By.xpath("//*[@id=\"recaptcha-anchor\"]/div[1]")).click();
//		driver.findElement(By.xpath("//*[@id=\"login\"]/li[5]/button")).click();
//		driver.findElementByXPath("//*[@id=\\\"login\\\"]/li[1]/app-email-input/div/input").click();
//	driver.findElementByXPath("/html/body/app-root/app-accounts/app-login/section/div/div/div/form/ul/li[1]/app-email-input/div/input").sendKeys("sneha");
		// driver.findElement(By.xpath("/html/body/app-root/app-accounts/app-login/section/div/div/div/form/ul/li[1]/app-email-input/div/input")).sendKeys("sneha");
		// driver.findElement(By.xpath("//*[@id=\"login\"]/li[1]/app-email-input/div/input")).sendKeys("sneha");
		// driver.findElementByCssSelector("#login > li:nth-child(1) > app-email-input >
		// div > input").sendKeys("sneha");
//		driver.findElement(By.cssSelector("input#login > li:nth-child(1) > app-email-input > div > input"))
//			.sendKeys("sneha");
		//driver.findElement(By.xpath("//input[@placeholder=\"Enter your password\"]")).sendKeys("Test@123");
		//driver.findElement(By.xpath("//*[@id=\"nav barSupportedContent\"]/ul/li/a")).click();
		// driver.findElement(By.xpath("/html/body/app-root/app-accounts/app-sign-up/section/div/div/div/form/ul/li[1]/app-text-box/div/input")).sendKeys("sneha");
//		 driver.findElement(By.xpath("(//input[@placeholder=\"Enter your email address\"])[1]")).sendKeys("sneha");
//		 driver.findElement(By.xpath(*[@id="sciout"]/tbody/tr[2]/td[2]/div/div[2]/span[1]")).sendKeys("sneha");
		  
		  //MULTIPLICATION
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[1]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[2]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[3]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[4]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[2]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[2]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[2]").click();
		Thread.sleep(2000);
		
	
		
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[5]/span[3]").click();
	    
		//DIVISION
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[1]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[4]/span[1]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[4]/span[1]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[4]/span[1]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[4]/span[4]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[2]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[4]/span[1]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[4]/span[1]").click();
		
		Thread.sleep(2000);

		
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[5]/span[3]").click();
		
		
		//ADDITION
		
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[4]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[2]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[3]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[1]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[2]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[3]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[1]").click();
	
	
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[1]/span[4]").click();

		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[3]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[1]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[2]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[3]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[1]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[2]").click();
		
			
		
		Thread.sleep(2000);
		
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[5]/span[3]").click();
		
		
		//SUBTRACTION
		
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[2]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[3]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[1]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[1]/span[2]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[2]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[3]").click();
		
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[4]").click();
		
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[1]/div/div[5]/span[1]").click();
		
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[4]").click();
		
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[2]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[3]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[4]/span[1]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[1]/span[3]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[1]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[1]/span[2]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[2]").click();
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[3]").click();	
		
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[1]/div/div[5]/span[2]").click();		
		Thread.sleep(2000);
		driver.findElementByXPath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[5]/span[3]").click();
		
		
		driver.close();
		
	
		
	}
}
